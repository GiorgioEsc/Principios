class Automovil():
    #Constructor
    def __init__(self):
     #Propiedades
        self.__largoChasis=250
        self.__anchoChasis=120
        self.__ruedas=4 #.___ Hace encapsulamiento
        self.__enmarcha=False
    
    #Metodos
    def arrancar(self,arrancamos):
        
        self.__enmarcha=arrancamos
        
        if(self.__enmarcha):
            chequeo=self.__chequeo_interno()
        
        if(self.__enmarcha and chequeo):
            return "El Automovil esta en marcha"
        
        elif(self.__enmarcha and chequeo ==False):
            return "Algo ha ido mal en el chequeo. No se puede arrancar "
        
        else: 
            return "El Automovil esta detenido"
        
    def estado (self):
        print("El Automovil tiene ", self.__ruedas, "Ruedas. Un ancho de ",self.__anchoChasis, " y un largo de ",
        self.__largoChasis)
        
    def __chequeo_interno (self):
        print "Iniciando el chequeo..."
        self.gasolina="Ok"
        self.aceite="Ok"
        self.puertas="Cerradas"
        
        if(self.gasolina=="Ok" and self.aceite=="Ok" and self.puertas=="Cerradas"):
            return True
        else: 
            return False
         

#Objetos 
renault=Automovil()
print renault.arrancar(True)
renault.estado()

print "------------------------------------------------------------------"
toyota=Automovil()
print toyota.arrancar(False)
toyota.estado()
